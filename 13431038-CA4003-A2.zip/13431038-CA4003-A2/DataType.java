public enum DataType
{
  Variable,
  Constant,
  Function
}
